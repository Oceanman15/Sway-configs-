ok so basically :

-data and data_schedule summon little xp orbs on top of other xp orbs
to have more xp noises when you collect xp

-merge, store, summon, summon_schedule and xporb_number_check all handle merging xp
together to reduce lag when killings lots of entities.